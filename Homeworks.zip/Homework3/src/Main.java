import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args){
        PlasticGoodsManufacturer jumbo = new PlasticGoodsManufacturer("jumbo");
        jumbo.addProduct(new PlasticGoods("toy", BigDecimal.valueOf(20)));
        jumbo.addProduct(new PlasticGoods("bottle", BigDecimal.valueOf(40)));
        jumbo.addProduct(new PlasticGoods("box", BigDecimal.valueOf(50)));
        jumbo.addProduct(new PlasticGoods("headphones", BigDecimal.valueOf(90)));
        jumbo.addProduct(new PlasticGoods("headphonesPremium", BigDecimal.valueOf(100)));

        System.out.println(jumbo.getMostExpensive());
        List<PlasticGoods> ls = new ArrayList<PlasticGoods>();
        ls = jumbo.moreExpensiveThanAvg();
        for (PlasticGoods item : ls){
            System.out.println(ls);
        }
    }
}
