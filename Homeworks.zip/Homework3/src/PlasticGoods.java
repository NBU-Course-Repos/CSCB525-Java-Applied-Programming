import java.math.BigDecimal;
import java.util.Comparator;
import java.util.stream.IntStream;

public class PlasticGoods implements Comparator<PlasticGoods> {
    private String name;
    private BigDecimal price;

    public PlasticGoods(String name, BigDecimal price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public int compare(PlasticGoods o1, PlasticGoods o2) {
        return 0;
    }

    public static Comparator<PlasticGoods> compareByPriceAscending = new Comparator<PlasticGoods>() {
        @Override
        public int compare(PlasticGoods o1, PlasticGoods o2) {
           return o1.price.compareTo(o2.price);
        }
    };

    @Override
    public String toString() {
        return "PlasticGoods{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public static Comparator<PlasticGoods> getCompareByPriceAscending() {
        return compareByPriceAscending;
    }

    public static void setCompareByPriceAscending(Comparator<PlasticGoods> compareByPriceAscending) {
        PlasticGoods.compareByPriceAscending = compareByPriceAscending;
    }
}
