import com.sun.source.tree.Tree;

import java.math.BigDecimal;
import java.util.*;

public class PlasticGoodsManufacturer {
    String name;
    TreeSet<PlasticGoods> plastics;

    public PlasticGoodsManufacturer(String name) {
        this.name = name;
        this.plastics = new TreeSet<PlasticGoods>(PlasticGoods.compareByPriceAscending);
    }

    private BigDecimal getAveragePrice(){
        BigDecimal avg = BigDecimal.valueOf(0);
        for (PlasticGoods pg : plastics){
            avg.add(pg.getPrice());
        }
        return avg.divide(BigDecimal.valueOf(plastics.size()));
    }

    public PlasticGoods getClosestToAvg(){
        PlasticGoods temp = new PlasticGoods("avg", getAveragePrice());
        return plastics.ceiling(temp);
    }

    public void addProduct(PlasticGoods pg){
        plastics.add(pg);
    }

    public void removeProduct(PlasticGoods pg){
        plastics.remove(pg);
    }

    public PlasticGoods getMostExpensive(){
        return plastics.last();
    }

    public List<PlasticGoods> moreExpensiveThanAvg(){
        PlasticGoods temp = new PlasticGoods("avg", getAveragePrice());
        List<PlasticGoods> result = new ArrayList<PlasticGoods>();
        for (PlasticGoods pg : plastics){
            if (pg.getPrice().compareTo(temp.getPrice()) == -1){
                result.add(pg);
            }
        }
        return result;
    }


}
