
public enum OrderType {
    STANDARD, FAST, EXPRESS
}
